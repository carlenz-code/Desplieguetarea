package services;

public interface ServicioB {

    public ServicioA getServicioA();

    public void setServicioA(ServicioA servicioA);

    public int multiplicarSumar(int a, int b, int multiplicador);

    public int multiplicar(int a, int b);
}
