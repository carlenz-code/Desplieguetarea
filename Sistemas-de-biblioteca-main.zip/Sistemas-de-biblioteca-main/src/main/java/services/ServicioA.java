package services;

public interface ServicioA {

    public abstract int sumar(int a,int b);

}
